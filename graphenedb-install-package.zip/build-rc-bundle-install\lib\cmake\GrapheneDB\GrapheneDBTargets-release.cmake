#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "GrapheneDB::graphenedb" for configuration "Release"
set_property(TARGET GrapheneDB::graphenedb APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(GrapheneDB::graphenedb PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libgraphenedb.a"
  )

list(APPEND _cmake_import_check_targets GrapheneDB::graphenedb )
list(APPEND _cmake_import_check_files_for_GrapheneDB::graphenedb "${_IMPORT_PREFIX}/lib/libgraphenedb.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
